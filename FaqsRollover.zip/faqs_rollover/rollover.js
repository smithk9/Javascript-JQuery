$(document).ready(function() {
    $("#faq_rollovers h2").click(
        function (evt) {
            $(this).toggleClass("minus");
            if ($(this).attr("class") !== "minus") {
                $(this).next().hide();
            }

            else {
                $(this).next().show();
            }
            evt.preventDefault();
        });//end click
    $("#faq_rollover").find("a:first").focus();

}); // end ready